# Data folder

In this folder we will keep our raw data. These are the images that we received.
